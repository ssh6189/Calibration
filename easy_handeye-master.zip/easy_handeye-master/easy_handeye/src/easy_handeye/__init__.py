
GET_SAMPLE_LIST_TOPIC = 'get_sample_list'
TAKE_SAMPLE_TOPIC = 'take_sample'
REMOVE_SAMPLE_TOPIC = 'remove_sample'
COMPUTE_CALIBRATION_TOPIC = 'compute_calibration'
SAVE_CALIBRATION_TOPIC = 'save_calibration'

CHECK_STARTING_POSE_TOPIC = 'check_starting_pose'
ENUMERATE_TARGET_POSES_TOPIC = 'enumerate_target_poses'
SELECT_TARGET_POSE_TOPIC = 'select_target_pose'
PLAN_TO_SELECTED_TARGET_POSE_TOPIC = 'plan_to_selected_target_pose'
EXECUTE_PLAN_TOPIC = 'execute_plan'
